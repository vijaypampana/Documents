import { Component } from '@angular/core';

@Component({
  selector: 'child-select',
  templateUrl: 'app/child-select.component.html'
})
export class ChildSelectComponent {
}