import {Component} from '@angular/core';

@Component({
    template: `
        <div class="medium-green">
            <h3>Medium</h3>
        </div>`,
    styles: ['.medium-green {background-color: #80ff80;}']
})
export class MediumGreenComponent {}