"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
const core_1 = require("@angular/core");
const actor_model_1 = require("./actor.model");
let AppComponent = class AppComponent {
    constructor() {
        this.slogan = 'Just movie information';
        this.title = 'Terminator 1';
        this.actor = new actor_model_1.Actor('Arnold', 'Schwarzenegger');
    }
    changeActorProperties() {
        this.actor.firstName = 'Nicholas';
        this.actor.lastName = 'Cage';
    }
    changeActorObject() {
        this.actor = new actor_model_1.Actor('Bruce', 'Willis');
    }
};
AppComponent = __decorate([
    core_1.Component({
        selector: 'app',
        template: `
    <h1>MovieApp</h1>
    <p>{{ slogan }}</p>
    <button type="button" (click)="changeActorProperties()">
      Change Actor Properties
    </button>
    <button type="button" (click)="changeActorObject()">
      Change Actor Object
    </button>
    <div style="margin:5px; font-family:verdana">The name of the Actor in the App Component is {{actor.firstName }}, {{actor.lastName}}</div>
    <app-movie [title]="title" [actor]="actor"></app-movie>`
    })
], AppComponent);
exports.AppComponent = AppComponent;
//# sourceMappingURL=app.component.js.map