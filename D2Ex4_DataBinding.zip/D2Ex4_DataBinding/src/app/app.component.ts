import { Component } from '@angular/core';
@Component({
  selector: 'app-root',
  template: `
    <div class="rendered">
      <binding-component layout-wrap layout-fill layout="row" layout-align="space-between"></binding-component>
    </div>
  `
  })
export class AppComponent {
  title = 'Angular 2. Data Binding';
      constructor() {
  }
}

