import {Component} from '@angular/core';

@Component({
  selector: 'component-aux',
  template: 'Component Aux'
})
export default class ComponentAux { 

}