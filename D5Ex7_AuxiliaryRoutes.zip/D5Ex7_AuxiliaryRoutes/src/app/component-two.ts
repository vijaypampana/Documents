import {Component} from '@angular/core';

@Component({
  selector: 'component-two',
  template: 'Component Two'
})
export default class ComponentTwo {
}