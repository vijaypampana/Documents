export interface Item {
  name: string;
  description: string;
}
