import {Component} from '@angular/core';

@Component({
    selector: 'app',
    template: `<h1>Hello {{ name }}! Welcome to your first and best Angular <b style='color:red;'>5</b> Example!!</h1>`
})
export class AppComponent {
    name: string;

    constructor() {
        this.name = 'Angular 5!!';
    }
}
