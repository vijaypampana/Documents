import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';

import { AppModule } from './directives/app.module';


platformBrowserDynamic().bootstrapModule(AppModule);
