import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { MyComponent } from './components/my.component';
import { App } from './app';


@NgModule({
  imports: [
    BrowserModule
  ],
  declarations: [
    MyComponent,
    App
   ],
  bootstrap: [ App ]
})
export class AppModule { 
}

platformBrowserDynamic().bootstrapModule(AppModule);