import { Component, QueryList, ViewChild, ViewChildren } from '@angular/core';
import { AlertComponent } from './alert.component';

@Component({
	selector: 'app-root',
	template: `
	<h3> ViewChildren </h3>
    <app-alert #first ok="Next" (close)="showAlert(2)">
      Step 1: Learn angular
    </app-alert>
    <app-alert ok="Next" (close)="showAlert(3)">
      Step 2: Love angular
    </app-alert>
    <app-alert ok="Close">
      Step 3: Build app
    </app-alert>
	  <button (click)="showAlert(1)">Show steps</button>

	  <h3> ContentChildren </h3>
	   <app-hello-list>
	    <app-hello name="World"></app-hello>
	    <app-hello name="Other World"></app-hello>
	    <app-hello #last name="Last World"></app-hello>
	  </app-hello-list>

     
	  <p>Calls function on child component classes to randomize color of them.</p>
	  `
})
export class AppComponent {
  @ViewChild('first') alert: AlertComponent;
  @ViewChildren(AlertComponent) alerts: QueryList<AlertComponent>;
   
  alertsArr = [];

  ngAfterViewInit() {
    this.alertsArr = this.alerts.toArray();
  }
  
  showAlert(step) {
    this.alertsArr[step - 1].show(); // step 1 is alert index 0
  }
}
